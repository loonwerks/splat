#ifndef SIREUM_H_hamr_SlangTypeLibrary_SlangTypeLibrary
#define SIREUM_H_hamr_SlangTypeLibrary_SlangTypeLibrary

#ifdef __cplusplus
extern "C" {
#endif

#include <types.h>

Unit hamr_SlangTypeLibrary_SlangTypeLibrary_main_printDataContent(STACK_FRAME art_DataContent a);

Z hamr_SlangTypeLibrary_SlangTypeLibrary_main(STACK_FRAME IS_948B60 args);

#ifdef __cplusplus
}
#endif

#endif