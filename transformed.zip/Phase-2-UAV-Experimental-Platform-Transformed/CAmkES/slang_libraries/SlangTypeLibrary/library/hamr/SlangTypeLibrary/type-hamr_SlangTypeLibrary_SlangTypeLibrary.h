#ifndef SIREUM_TYPE_H_hamr_SlangTypeLibrary_SlangTypeLibrary
#define SIREUM_TYPE_H_hamr_SlangTypeLibrary_SlangTypeLibrary

#ifdef __cplusplus
extern "C" {
#endif

#include <misc.h>


#ifdef __cplusplus
}
#endif

#endif