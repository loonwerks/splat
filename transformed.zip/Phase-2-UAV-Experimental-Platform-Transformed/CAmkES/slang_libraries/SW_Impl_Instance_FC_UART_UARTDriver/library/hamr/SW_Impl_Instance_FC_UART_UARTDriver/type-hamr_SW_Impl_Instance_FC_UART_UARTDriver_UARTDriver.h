#ifndef SIREUM_TYPE_H_hamr_SW_Impl_Instance_FC_UART_UARTDriver_UARTDriver
#define SIREUM_TYPE_H_hamr_SW_Impl_Instance_FC_UART_UARTDriver_UARTDriver

#ifdef __cplusplus
extern "C" {
#endif

#include <misc.h>


#ifdef __cplusplus
}
#endif

#endif