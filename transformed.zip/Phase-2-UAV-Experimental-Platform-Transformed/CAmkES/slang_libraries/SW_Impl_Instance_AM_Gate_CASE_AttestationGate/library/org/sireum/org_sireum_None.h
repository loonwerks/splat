#ifndef SIREUM_H_org_sireum_None
#define SIREUM_H_org_sireum_None

#ifdef __cplusplus
extern "C" {
#endif

#include <types.h>

B None_964667_nonEmpty_(STACK_FRAME None_964667 this);

void None_964667_get_(STACK_FRAME art_DataContent result, None_964667 this);

#ifdef __cplusplus
}
#endif

#endif