#ifndef SIREUM_H_org_sireum_Some
#define SIREUM_H_org_sireum_Some

#ifdef __cplusplus
extern "C" {
#endif

#include <types.h>

B Some_D29615_nonEmpty_(STACK_FRAME Some_D29615 this);

void Some_D29615_get_(STACK_FRAME art_DataContent result, Some_D29615 this);

#ifdef __cplusplus
}
#endif

#endif