#ifndef SIREUM_TYPE_H_org_sireum_None
#define SIREUM_TYPE_H_org_sireum_None

#ifdef __cplusplus
extern "C" {
#endif

#include <misc.h>


#ifdef __cplusplus
}
#endif

#endif