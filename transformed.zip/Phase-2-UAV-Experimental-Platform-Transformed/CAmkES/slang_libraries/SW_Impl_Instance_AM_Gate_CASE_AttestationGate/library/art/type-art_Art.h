#ifndef SIREUM_TYPE_H_art_Art
#define SIREUM_TYPE_H_art_Art

#ifdef __cplusplus
extern "C" {
#endif

#include <misc.h>


#ifdef __cplusplus
}
#endif

#endif