#ifndef SIREUM_TYPE_H_hamr_Base_Types
#define SIREUM_TYPE_H_hamr_Base_Types

#ifdef __cplusplus
extern "C" {
#endif

#include <misc.h>


#ifdef __cplusplus
}
#endif

#endif