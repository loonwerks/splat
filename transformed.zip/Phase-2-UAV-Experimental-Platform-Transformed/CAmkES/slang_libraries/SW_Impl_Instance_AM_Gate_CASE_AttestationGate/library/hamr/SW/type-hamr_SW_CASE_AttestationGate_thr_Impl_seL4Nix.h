#ifndef SIREUM_TYPE_H_hamr_SW_CASE_AttestationGate_thr_Impl_seL4Nix
#define SIREUM_TYPE_H_hamr_SW_CASE_AttestationGate_thr_Impl_seL4Nix

#ifdef __cplusplus
extern "C" {
#endif

#include <misc.h>


#ifdef __cplusplus
}
#endif

#endif