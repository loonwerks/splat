#ifndef SIREUM_H_hamr_Base_Types
#define SIREUM_H_hamr_Base_Types

#ifdef __cplusplus
extern "C" {
#endif

#include <types.h>

void hamr_Base_Types_Bits_empty(STACK_FRAME IS_C4F575 result);

#ifdef __cplusplus
}
#endif

#endif