#ifndef SIREUM_TYPE_H_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate
#define SIREUM_TYPE_H_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate

#ifdef __cplusplus
extern "C" {
#endif

#include <misc.h>


#ifdef __cplusplus
}
#endif

#endif