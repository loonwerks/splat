#include <all.h>

B hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_initialized_ = F;

struct hamr_SW_CASE_AttestationGate_thr_Impl_Bridge _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_CASE_AttestationGateBridge;
union art_Bridge_EntryPoints _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_entryPoints;
union Option_8E9F45 _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_noData;
Z _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_trusted_ids_id;
union Option_8E9F45 _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_trusted_ids_port;
Z _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_AutomationRequest_in_id;
union Option_8E9F45 _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_AutomationRequest_in_port;
Z _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_AutomationRequest_out_id;
union Option_8E9F45 _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_AutomationRequest_out_port;
Z _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_OperatingRegion_in_id;
union Option_8E9F45 _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_OperatingRegion_in_port;
Z _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_OperatingRegion_out_id;
union Option_8E9F45 _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_OperatingRegion_out_port;
Z _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_LineSearchTask_in_id;
union Option_8E9F45 _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_LineSearchTask_in_port;
Z _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_LineSearchTask_out_id;
union Option_8E9F45 _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_LineSearchTask_out_port;

void hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init(STACK_FRAME_ONLY) {
  if (hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_initialized_) return;
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_initialized_ = T;
  DeclNewStackFrame(caller, "CASE_AttestationGate.scala", "hamr.SW_Impl_Instance_AM_Gate_CASE_AttestationGate.CASE_AttestationGate", "<init>", 0);
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_CASE_AttestationGateBridge(SF_LAST);
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_entryPoints(SF_LAST);
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_noData(SF_LAST);
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_trusted_ids_id(SF_LAST);
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_trusted_ids_port(SF_LAST);
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_AutomationRequest_in_id(SF_LAST);
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_AutomationRequest_in_port(SF_LAST);
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_AutomationRequest_out_id(SF_LAST);
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_AutomationRequest_out_port(SF_LAST);
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_OperatingRegion_in_id(SF_LAST);
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_OperatingRegion_in_port(SF_LAST);
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_OperatingRegion_out_id(SF_LAST);
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_OperatingRegion_out_port(SF_LAST);
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_LineSearchTask_in_id(SF_LAST);
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_LineSearchTask_in_port(SF_LAST);
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_LineSearchTask_out_id(SF_LAST);
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_LineSearchTask_out_port(SF_LAST);
}

hamr_SW_CASE_AttestationGate_thr_Impl_Bridge hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_CASE_AttestationGateBridge(STACK_FRAME_ONLY) {
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init(CALLER_LAST);
  return (hamr_SW_CASE_AttestationGate_thr_Impl_Bridge) &_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_CASE_AttestationGateBridge;
}

art_Bridge_EntryPoints hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_entryPoints(STACK_FRAME_ONLY) {
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init(CALLER_LAST);
  return (art_Bridge_EntryPoints) &_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_entryPoints;
}

Option_8E9F45 hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_noData(STACK_FRAME_ONLY) {
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init(CALLER_LAST);
  return (Option_8E9F45) &_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_noData;
}

Z hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_trusted_ids_id(STACK_FRAME_ONLY) {
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init(CALLER_LAST);
  return _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_trusted_ids_id;
}

Option_8E9F45 hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_trusted_ids_port(STACK_FRAME_ONLY) {
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init(CALLER_LAST);
  return (Option_8E9F45) &_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_trusted_ids_port;
}

void hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_trusted_ids_port_a(STACK_FRAME Option_8E9F45 p_trusted_ids_port) {
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init(CALLER_LAST);
  Type_assign(&_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_trusted_ids_port, p_trusted_ids_port, sizeof(union Option_8E9F45));
}

Z hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_AutomationRequest_in_id(STACK_FRAME_ONLY) {
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init(CALLER_LAST);
  return _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_AutomationRequest_in_id;
}

Option_8E9F45 hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_AutomationRequest_in_port(STACK_FRAME_ONLY) {
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init(CALLER_LAST);
  return (Option_8E9F45) &_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_AutomationRequest_in_port;
}

void hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_AutomationRequest_in_port_a(STACK_FRAME Option_8E9F45 p_AutomationRequest_in_port) {
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init(CALLER_LAST);
  Type_assign(&_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_AutomationRequest_in_port, p_AutomationRequest_in_port, sizeof(union Option_8E9F45));
}

Z hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_AutomationRequest_out_id(STACK_FRAME_ONLY) {
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init(CALLER_LAST);
  return _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_AutomationRequest_out_id;
}

Option_8E9F45 hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_AutomationRequest_out_port(STACK_FRAME_ONLY) {
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init(CALLER_LAST);
  return (Option_8E9F45) &_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_AutomationRequest_out_port;
}

void hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_AutomationRequest_out_port_a(STACK_FRAME Option_8E9F45 p_AutomationRequest_out_port) {
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init(CALLER_LAST);
  Type_assign(&_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_AutomationRequest_out_port, p_AutomationRequest_out_port, sizeof(union Option_8E9F45));
}

Z hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_OperatingRegion_in_id(STACK_FRAME_ONLY) {
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init(CALLER_LAST);
  return _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_OperatingRegion_in_id;
}

Option_8E9F45 hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_OperatingRegion_in_port(STACK_FRAME_ONLY) {
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init(CALLER_LAST);
  return (Option_8E9F45) &_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_OperatingRegion_in_port;
}

void hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_OperatingRegion_in_port_a(STACK_FRAME Option_8E9F45 p_OperatingRegion_in_port) {
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init(CALLER_LAST);
  Type_assign(&_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_OperatingRegion_in_port, p_OperatingRegion_in_port, sizeof(union Option_8E9F45));
}

Z hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_OperatingRegion_out_id(STACK_FRAME_ONLY) {
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init(CALLER_LAST);
  return _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_OperatingRegion_out_id;
}

Option_8E9F45 hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_OperatingRegion_out_port(STACK_FRAME_ONLY) {
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init(CALLER_LAST);
  return (Option_8E9F45) &_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_OperatingRegion_out_port;
}

void hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_OperatingRegion_out_port_a(STACK_FRAME Option_8E9F45 p_OperatingRegion_out_port) {
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init(CALLER_LAST);
  Type_assign(&_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_OperatingRegion_out_port, p_OperatingRegion_out_port, sizeof(union Option_8E9F45));
}

Z hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_LineSearchTask_in_id(STACK_FRAME_ONLY) {
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init(CALLER_LAST);
  return _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_LineSearchTask_in_id;
}

Option_8E9F45 hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_LineSearchTask_in_port(STACK_FRAME_ONLY) {
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init(CALLER_LAST);
  return (Option_8E9F45) &_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_LineSearchTask_in_port;
}

void hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_LineSearchTask_in_port_a(STACK_FRAME Option_8E9F45 p_LineSearchTask_in_port) {
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init(CALLER_LAST);
  Type_assign(&_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_LineSearchTask_in_port, p_LineSearchTask_in_port, sizeof(union Option_8E9F45));
}

Z hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_LineSearchTask_out_id(STACK_FRAME_ONLY) {
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init(CALLER_LAST);
  return _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_LineSearchTask_out_id;
}

Option_8E9F45 hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_LineSearchTask_out_port(STACK_FRAME_ONLY) {
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init(CALLER_LAST);
  return (Option_8E9F45) &_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_LineSearchTask_out_port;
}

void hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_LineSearchTask_out_port_a(STACK_FRAME Option_8E9F45 p_LineSearchTask_out_port) {
  hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init(CALLER_LAST);
  Type_assign(&_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_LineSearchTask_out_port, p_LineSearchTask_out_port, sizeof(union Option_8E9F45));
}

Unit hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_main_printDataContent(STACK_FRAME art_DataContent a) {
  DeclNewStackFrame(caller, "CASE_AttestationGate.scala", "hamr.SW_Impl_Instance_AM_Gate_CASE_AttestationGate.CASE_AttestationGate.main", "printDataContent", 0);

  #ifndef SIREUM_NO_PRINT

  sfUpdateLoc(154);
  {
    DeclNewString(t_0);
    String_string_(SF (String) &t_0, string(""));
    art_DataContent_string_(SF (String) &t_0, a);
    String_string_(SF (String) &t_0, string(""));
    String_cprint(((String) &t_0), T);
    cprintln(T);
    cflush(T);
  }

  #endif
}

Z hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_main(STACK_FRAME IS_948B60 args) {
  DeclNewStackFrame(caller, "CASE_AttestationGate.scala", "hamr.SW_Impl_Instance_AM_Gate_CASE_AttestationGate.CASE_AttestationGate", "main", 0);

  sfUpdateLoc(148);
  {
    hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_initialiseArchitecture(SF_LAST);
  }

  sfUpdateLoc(149);
  {
    hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_initialiseEntryPoint(SF_LAST);
  }

  sfUpdateLoc(150);
  {
    hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_computeEntryPoint(SF_LAST);
  }

  sfUpdateLoc(151);
  {
    hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_finaliseEntryPoint(SF_LAST);
  }

  sfUpdateLoc(156);
  {
    DeclNewIS_C4F575(t_1);
    hamr_Base_Types_Bits_empty(SF (IS_C4F575) &t_1);
    DeclNewhamr_Base_Types_Bits_Payload(t_0);
    hamr_Base_Types_Bits_Payload_apply(SF &t_0, (IS_C4F575) ((IS_C4F575) &t_1));
    hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_main_printDataContent(SF (art_DataContent) (&t_0));
  }

  sfUpdateLoc(157);
  {
    DeclNewart_Empty(t_2);
    art_Empty_apply(SF &t_2);
    hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_main_printDataContent(SF (art_DataContent) (&t_2));
  }
  return Z_C(0);
}

Unit hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_initialiseArchitecture(STACK_FRAME_ONLY) {
  DeclNewStackFrame(caller, "CASE_AttestationGate.scala", "hamr.SW_Impl_Instance_AM_Gate_CASE_AttestationGate.CASE_AttestationGate", "initialiseArchitecture", 0);

  sfUpdateLoc(132);
  DeclNewart_ArchitectureDescription(_ad);
  art_ArchitectureDescription ad = (art_ArchitectureDescription) &_ad;
  {
    STATIC_ASSERT(1 <= MaxMS_852149, "Insufficient maximum for MS[Z, art.Bridge] elements.");
    DeclNewMS_852149(t_1);
    t_1.size = (int8_t) 1;
    MS_852149_up(&t_1, 0, (art_Bridge) hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_CASE_AttestationGateBridge(SF_LAST));
    STATIC_ASSERT(0 <= MaxIS_08117A, "Insufficient maximum for IS[Z, art.UConnection] elements.");
    DeclNewIS_08117A(t_2);
    t_2.size = (int8_t) 0;
    DeclNewart_ArchitectureDescription(t_0);
    art_ArchitectureDescription_apply(SF &t_0, (MS_852149) (&t_1), (IS_08117A) (&t_2));
    Type_assign(ad, (&t_0), sizeof(struct art_ArchitectureDescription));
  }

  sfUpdateLoc(136);
  {
    art_Art_run(SF (art_ArchitectureDescription) ad);
  }
}

Unit hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_initialiseEntryPoint(STACK_FRAME_ONLY) {
  DeclNewStackFrame(caller, "CASE_AttestationGate.scala", "hamr.SW_Impl_Instance_AM_Gate_CASE_AttestationGate.CASE_AttestationGate", "initialiseEntryPoint", 0);

  sfUpdateLoc(139);
  {
    art_Bridge_EntryPoints_initialise_(SF hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_entryPoints(SF_LAST));
  }
}

Unit hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_computeEntryPoint(STACK_FRAME_ONLY) {
  DeclNewStackFrame(caller, "CASE_AttestationGate.scala", "hamr.SW_Impl_Instance_AM_Gate_CASE_AttestationGate.CASE_AttestationGate", "computeEntryPoint", 0);

  sfUpdateLoc(141);
  {
    art_Bridge_EntryPoints_compute_(SF hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_entryPoints(SF_LAST));
  }
}

Unit hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_finaliseEntryPoint(STACK_FRAME_ONLY) {
  DeclNewStackFrame(caller, "CASE_AttestationGate.scala", "hamr.SW_Impl_Instance_AM_Gate_CASE_AttestationGate.CASE_AttestationGate", "finaliseEntryPoint", 0);

  sfUpdateLoc(143);
  {
    art_Bridge_EntryPoints_finalise_(SF hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_entryPoints(SF_LAST));
  }
}

Unit hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_run(STACK_FRAME_ONLY) {
  DeclNewStackFrame(caller, "CASE_AttestationGate.scala", "hamr.SW_Impl_Instance_AM_Gate_CASE_AttestationGate.CASE_AttestationGate", "run", 0);
}

Unit hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_logInfo(STACK_FRAME String title, String msg) {
  DeclNewStackFrame(caller, "CASE_AttestationGate.scala", "hamr.SW_Impl_Instance_AM_Gate_CASE_AttestationGate.CASE_AttestationGate", "logInfo", 0);

  #ifndef SIREUM_NO_PRINT

  sfUpdateLoc(163);
  {
    String_cprint(title, T);
  }

  #endif

  #ifndef SIREUM_NO_PRINT

  sfUpdateLoc(164);
  {
    String_cprint(string(": "), T);
  }

  #endif

  #ifndef SIREUM_NO_PRINT

  sfUpdateLoc(165);
  {
    String_cprint(msg, T);
    cprintln(T);
    cflush(T);
  }

  #endif
}

Unit hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_sendOutput(STACK_FRAME IS_82ABD8 eventPortIds, IS_82ABD8 dataPortIds) {
  DeclNewStackFrame(caller, "CASE_AttestationGate.scala", "hamr.SW_Impl_Instance_AM_Gate_CASE_AttestationGate.CASE_AttestationGate", "sendOutput", 0);

  sfUpdateLoc(115);
  B t_0;
  {
    B t_1 = Option_8E9F45_nonEmpty_(SF hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_AutomationRequest_out_port(SF_LAST));
    t_0 = t_1;
  }
  if (t_0) {

    sfUpdateLoc(116);
    {
      DeclNewart_DataContent(t_2);
      Option_8E9F45_get_(SF (art_DataContent) &t_2, hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_AutomationRequest_out_port(SF_LAST));
      hamr_SW_CASE_AttestationGate_thr_Impl_seL4Nix_AutomationRequest_out_Send(SF (art_DataContent) ((art_DataContent) &t_2));
    }

    sfUpdateLoc(117);
    {
      hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_AutomationRequest_out_port_a(SF (Option_8E9F45) hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_noData(SF_LAST));
    }
  }

  sfUpdateLoc(120);
  B t_3;
  {
    B t_4 = Option_8E9F45_nonEmpty_(SF hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_OperatingRegion_out_port(SF_LAST));
    t_3 = t_4;
  }
  if (t_3) {

    sfUpdateLoc(121);
    {
      DeclNewart_DataContent(t_5);
      Option_8E9F45_get_(SF (art_DataContent) &t_5, hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_OperatingRegion_out_port(SF_LAST));
      hamr_SW_CASE_AttestationGate_thr_Impl_seL4Nix_OperatingRegion_out_Send(SF (art_DataContent) ((art_DataContent) &t_5));
    }

    sfUpdateLoc(122);
    {
      hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_OperatingRegion_out_port_a(SF (Option_8E9F45) hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_noData(SF_LAST));
    }
  }

  sfUpdateLoc(125);
  B t_6;
  {
    B t_7 = Option_8E9F45_nonEmpty_(SF hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_LineSearchTask_out_port(SF_LAST));
    t_6 = t_7;
  }
  if (t_6) {

    sfUpdateLoc(126);
    {
      DeclNewart_DataContent(t_8);
      Option_8E9F45_get_(SF (art_DataContent) &t_8, hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_LineSearchTask_out_port(SF_LAST));
      hamr_SW_CASE_AttestationGate_thr_Impl_seL4Nix_LineSearchTask_out_Send(SF (art_DataContent) ((art_DataContent) &t_8));
    }

    sfUpdateLoc(127);
    {
      hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_LineSearchTask_out_port_a(SF (Option_8E9F45) hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_noData(SF_LAST));
    }
  }
}

Unit hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_receiveInput(STACK_FRAME IS_82ABD8 eventPortIds, IS_82ABD8 dataPortIds) {
  DeclNewStackFrame(caller, "CASE_AttestationGate.scala", "hamr.SW_Impl_Instance_AM_Gate_CASE_AttestationGate.CASE_AttestationGate", "receiveInput", 0);

  sfUpdateLoc(91);
  {
    DeclNewOption_8E9F45(t_0);
    hamr_SW_CASE_AttestationGate_thr_Impl_seL4Nix_trusted_ids_Receive(SF (Option_8E9F45) &t_0);
    hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_trusted_ids_port_a(SF (Option_8E9F45) ((Option_8E9F45) &t_0));
  }

  sfUpdateLoc(93);
  {
    DeclNewOption_8E9F45(t_1);
    hamr_SW_CASE_AttestationGate_thr_Impl_seL4Nix_AutomationRequest_in_Receive(SF (Option_8E9F45) &t_1);
    hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_AutomationRequest_in_port_a(SF (Option_8E9F45) ((Option_8E9F45) &t_1));
  }

  sfUpdateLoc(95);
  {
    DeclNewOption_8E9F45(t_2);
    hamr_SW_CASE_AttestationGate_thr_Impl_seL4Nix_OperatingRegion_in_Receive(SF (Option_8E9F45) &t_2);
    hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_OperatingRegion_in_port_a(SF (Option_8E9F45) ((Option_8E9F45) &t_2));
  }

  sfUpdateLoc(97);
  {
    DeclNewOption_8E9F45(t_3);
    hamr_SW_CASE_AttestationGate_thr_Impl_seL4Nix_LineSearchTask_in_Receive(SF (Option_8E9F45) &t_3);
    hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_LineSearchTask_in_port_a(SF (Option_8E9F45) ((Option_8E9F45) &t_3));
  }
}

Unit hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_logDebug(STACK_FRAME String title, String msg) {
  DeclNewStackFrame(caller, "CASE_AttestationGate.scala", "hamr.SW_Impl_Instance_AM_Gate_CASE_AttestationGate.CASE_AttestationGate", "logDebug", 0);

  #ifndef SIREUM_NO_PRINT

  sfUpdateLoc(175);
  {
    String_cprint(title, T);
  }

  #endif

  #ifndef SIREUM_NO_PRINT

  sfUpdateLoc(176);
  {
    String_cprint(string(": "), T);
  }

  #endif

  #ifndef SIREUM_NO_PRINT

  sfUpdateLoc(177);
  {
    String_cprint(msg, T);
    cprintln(T);
    cflush(T);
  }

  #endif
}

Unit hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_logError(STACK_FRAME String title, String msg) {
  DeclNewStackFrame(caller, "CASE_AttestationGate.scala", "hamr.SW_Impl_Instance_AM_Gate_CASE_AttestationGate.CASE_AttestationGate", "logError", 0);

  #ifndef SIREUM_NO_PRINT

  sfUpdateLoc(169);
  {
    String_cprint(title, F);
  }

  #endif

  #ifndef SIREUM_NO_PRINT

  sfUpdateLoc(170);
  {
    String_cprint(string(": "), F);
  }

  #endif

  #ifndef SIREUM_NO_PRINT

  sfUpdateLoc(171);
  {
    String_cprint(msg, F);
    cprintln(F);
    cflush(F);
  }

  #endif
}

void hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_getValue(STACK_FRAME Option_8E9F45 result, Z portId) {
  DeclNewStackFrame(caller, "CASE_AttestationGate.scala", "hamr.SW_Impl_Instance_AM_Gate_CASE_AttestationGate.CASE_AttestationGate", "getValue", 0);

  sfUpdateLoc(75);
  B t_0;
  {
    t_0 = Z__eq(portId, hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_trusted_ids_id(SF_LAST));
  }
  if (t_0) {
    Type_assign(result, hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_trusted_ids_port(SF_LAST), sizeof(union Option_8E9F45));
    return;
  } else {

    sfUpdateLoc(77);
    B t_1;
    {
      t_1 = Z__eq(portId, hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_AutomationRequest_in_id(SF_LAST));
    }
    if (t_1) {
      Type_assign(result, hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_AutomationRequest_in_port(SF_LAST), sizeof(union Option_8E9F45));
      return;
    } else {

      sfUpdateLoc(79);
      B t_2;
      {
        t_2 = Z__eq(portId, hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_OperatingRegion_in_id(SF_LAST));
      }
      if (t_2) {
        Type_assign(result, hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_OperatingRegion_in_port(SF_LAST), sizeof(union Option_8E9F45));
        return;
      } else {

        sfUpdateLoc(81);
        B t_3;
        {
          t_3 = Z__eq(portId, hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_LineSearchTask_in_id(SF_LAST));
        }
        if (t_3) {
          Type_assign(result, hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_LineSearchTask_in_port(SF_LAST), sizeof(union Option_8E9F45));
          return;
        } else {

          sfUpdateLoc(84);
          {
            DeclNewString(t_4);
            String t_5 = (String) &t_4;
            DeclNewString(t_6);
            String_string_(SF (String) &t_6, string("Unexpected: CASE_AttestationGate.getValue called with: "));
            Z_string_(SF (String) &t_6, portId);
            String_string_(SF (String) &t_6, string(""));
            String_string_(SF t_5, ((String) &t_6));
            sfAbort(t_5->value);
            abort();
          }
        }
      }
    }
  }
}

Unit hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_putValue(STACK_FRAME Z portId, art_DataContent data) {
  DeclNewStackFrame(caller, "CASE_AttestationGate.scala", "hamr.SW_Impl_Instance_AM_Gate_CASE_AttestationGate.CASE_AttestationGate", "putValue", 0);

  sfUpdateLoc(101);
  B t_0;
  {
    t_0 = Z__eq(portId, hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_AutomationRequest_out_id(SF_LAST));
  }
  if (t_0) {

    sfUpdateLoc(102);
    {
      DeclNewSome_D29615(t_1);
      Some_D29615_apply(SF &t_1, (art_DataContent) data);
      hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_AutomationRequest_out_port_a(SF (Option_8E9F45) (&t_1));
    }
  } else {

    sfUpdateLoc(103);
    B t_2;
    {
      t_2 = Z__eq(portId, hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_OperatingRegion_out_id(SF_LAST));
    }
    if (t_2) {

      sfUpdateLoc(104);
      {
        DeclNewSome_D29615(t_3);
        Some_D29615_apply(SF &t_3, (art_DataContent) data);
        hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_OperatingRegion_out_port_a(SF (Option_8E9F45) (&t_3));
      }
    } else {

      sfUpdateLoc(105);
      B t_4;
      {
        t_4 = Z__eq(portId, hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_LineSearchTask_out_id(SF_LAST));
      }
      if (t_4) {

        sfUpdateLoc(106);
        {
          DeclNewSome_D29615(t_5);
          Some_D29615_apply(SF &t_5, (art_DataContent) data);
          hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_LineSearchTask_out_port_a(SF (Option_8E9F45) (&t_5));
        }
      } else {

        sfUpdateLoc(108);
        {
          DeclNewString(t_6);
          String t_7 = (String) &t_6;
          DeclNewString(t_8);
          String_string_(SF (String) &t_8, string("Unexpected: CASE_AttestationGate.putValue called with: "));
          Z_string_(SF (String) &t_8, portId);
          String_string_(SF (String) &t_8, string(""));
          String_string_(SF t_7, ((String) &t_8));
          sfAbort(t_7->value);
          abort();
        }
      }
    }
  }
}

void hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_CASE_AttestationGateBridge(STACK_FRAME_ONLY) {
  #ifdef SIREUM_LOC
  StackFrame sf = caller;
  #endif
  sfUpdateLoc(14);
  {

    sfUpdateLoc(15);
    art_Port_45E54D trusted_ids;
    DeclNewart_Port_45E54D(t_0);
    art_Port_45E54D_apply(SF &t_0, Z_C(0), (String) string("SW_Impl_Instance_AM_Gate_CASE_AttestationGate_trusted_ids"), art_PortMode_Type_DataIn);
    trusted_ids = (art_Port_45E54D) (&t_0);

    sfUpdateLoc(16);
    art_Port_45E54D AutomationRequest_in;
    DeclNewart_Port_45E54D(t_1);
    art_Port_45E54D_apply(SF &t_1, Z_C(1), (String) string("SW_Impl_Instance_AM_Gate_CASE_AttestationGate_AutomationRequest_in"), art_PortMode_Type_EventIn);
    AutomationRequest_in = (art_Port_45E54D) (&t_1);

    sfUpdateLoc(17);
    art_Port_45E54D AutomationRequest_out;
    DeclNewart_Port_45E54D(t_2);
    art_Port_45E54D_apply(SF &t_2, Z_C(2), (String) string("SW_Impl_Instance_AM_Gate_CASE_AttestationGate_AutomationRequest_out"), art_PortMode_Type_EventOut);
    AutomationRequest_out = (art_Port_45E54D) (&t_2);

    sfUpdateLoc(18);
    art_Port_45E54D OperatingRegion_in;
    DeclNewart_Port_45E54D(t_3);
    art_Port_45E54D_apply(SF &t_3, Z_C(3), (String) string("SW_Impl_Instance_AM_Gate_CASE_AttestationGate_OperatingRegion_in"), art_PortMode_Type_EventIn);
    OperatingRegion_in = (art_Port_45E54D) (&t_3);

    sfUpdateLoc(19);
    art_Port_45E54D OperatingRegion_out;
    DeclNewart_Port_45E54D(t_4);
    art_Port_45E54D_apply(SF &t_4, Z_C(4), (String) string("SW_Impl_Instance_AM_Gate_CASE_AttestationGate_OperatingRegion_out"), art_PortMode_Type_EventOut);
    OperatingRegion_out = (art_Port_45E54D) (&t_4);

    sfUpdateLoc(20);
    art_Port_45E54D LineSearchTask_in;
    DeclNewart_Port_45E54D(t_5);
    art_Port_45E54D_apply(SF &t_5, Z_C(5), (String) string("SW_Impl_Instance_AM_Gate_CASE_AttestationGate_LineSearchTask_in"), art_PortMode_Type_EventIn);
    LineSearchTask_in = (art_Port_45E54D) (&t_5);

    sfUpdateLoc(21);
    art_Port_45E54D LineSearchTask_out;
    DeclNewart_Port_45E54D(t_6);
    art_Port_45E54D_apply(SF &t_6, Z_C(6), (String) string("SW_Impl_Instance_AM_Gate_CASE_AttestationGate_LineSearchTask_out"), art_PortMode_Type_EventOut);
    LineSearchTask_out = (art_Port_45E54D) (&t_6);
    DeclNewart_DispatchPropertyProtocol_Periodic(t_8);
    art_DispatchPropertyProtocol_Periodic_apply(SF &t_8, Z_C(500));
    DeclNewNone_5C1355(t_9);
    None_5C1355_apply(SF &t_9);
    DeclNewhamr_SW_CASE_AttestationGate_thr_Impl_Bridge(t_7);
    hamr_SW_CASE_AttestationGate_thr_Impl_Bridge_apply(SF &t_7, Z_C(0), (String) string("SW_Impl_Instance_AM_Gate_CASE_AttestationGate"), (art_DispatchPropertyProtocol) (&t_8), (Option_9AF35E) (&t_9), (art_Port_45E54D) trusted_ids, (art_Port_45E54D) AutomationRequest_in, (art_Port_45E54D) AutomationRequest_out, (art_Port_45E54D) OperatingRegion_in, (art_Port_45E54D) OperatingRegion_out, (art_Port_45E54D) LineSearchTask_in, (art_Port_45E54D) LineSearchTask_out);
    Type_assign(&_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_CASE_AttestationGateBridge, (&t_7), sizeof(struct hamr_SW_CASE_AttestationGate_thr_Impl_Bridge));
  }
};

void hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_entryPoints(STACK_FRAME_ONLY) {
  #ifdef SIREUM_LOC
  StackFrame sf = caller;
  #endif
  sfUpdateLoc(39);
  Type_assign(&_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_entryPoints, hamr_SW_CASE_AttestationGate_thr_Impl_Bridge_entryPoints_(hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_CASE_AttestationGateBridge(SF_LAST)), sizeof(union art_Bridge_EntryPoints));
};

void hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_noData(STACK_FRAME_ONLY) {
  #ifdef SIREUM_LOC
  StackFrame sf = caller;
  #endif
  sfUpdateLoc(40);
  DeclNewNone_964667(t_10);
  None_964667_apply(SF &t_10);
  Type_assign(&_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_noData, (&t_10), sizeof(struct None_964667));
};

void hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_trusted_ids_id(STACK_FRAME_ONLY) {
  #ifdef SIREUM_LOC
  StackFrame sf = caller;
  #endif
  sfUpdateLoc(43);
  _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_trusted_ids_id = art_Port_45E54D_id_(hamr_SW_CASE_AttestationGate_thr_Impl_Bridge_trusted_ids_(hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_CASE_AttestationGateBridge(SF_LAST)));
};

void hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_trusted_ids_port(STACK_FRAME_ONLY) {
  #ifdef SIREUM_LOC
  StackFrame sf = caller;
  #endif
  sfUpdateLoc(44);
  Type_assign(&_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_trusted_ids_port, hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_noData(SF_LAST), sizeof(union Option_8E9F45));
};

void hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_AutomationRequest_in_id(STACK_FRAME_ONLY) {
  #ifdef SIREUM_LOC
  StackFrame sf = caller;
  #endif
  sfUpdateLoc(47);
  _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_AutomationRequest_in_id = art_Port_45E54D_id_(hamr_SW_CASE_AttestationGate_thr_Impl_Bridge_AutomationRequest_in_(hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_CASE_AttestationGateBridge(SF_LAST)));
};

void hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_AutomationRequest_in_port(STACK_FRAME_ONLY) {
  #ifdef SIREUM_LOC
  StackFrame sf = caller;
  #endif
  sfUpdateLoc(48);
  Type_assign(&_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_AutomationRequest_in_port, hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_noData(SF_LAST), sizeof(union Option_8E9F45));
};

void hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_AutomationRequest_out_id(STACK_FRAME_ONLY) {
  #ifdef SIREUM_LOC
  StackFrame sf = caller;
  #endif
  sfUpdateLoc(51);
  _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_AutomationRequest_out_id = art_Port_45E54D_id_(hamr_SW_CASE_AttestationGate_thr_Impl_Bridge_AutomationRequest_out_(hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_CASE_AttestationGateBridge(SF_LAST)));
};

void hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_AutomationRequest_out_port(STACK_FRAME_ONLY) {
  #ifdef SIREUM_LOC
  StackFrame sf = caller;
  #endif
  sfUpdateLoc(52);
  Type_assign(&_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_AutomationRequest_out_port, hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_noData(SF_LAST), sizeof(union Option_8E9F45));
};

void hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_OperatingRegion_in_id(STACK_FRAME_ONLY) {
  #ifdef SIREUM_LOC
  StackFrame sf = caller;
  #endif
  sfUpdateLoc(55);
  _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_OperatingRegion_in_id = art_Port_45E54D_id_(hamr_SW_CASE_AttestationGate_thr_Impl_Bridge_OperatingRegion_in_(hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_CASE_AttestationGateBridge(SF_LAST)));
};

void hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_OperatingRegion_in_port(STACK_FRAME_ONLY) {
  #ifdef SIREUM_LOC
  StackFrame sf = caller;
  #endif
  sfUpdateLoc(56);
  Type_assign(&_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_OperatingRegion_in_port, hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_noData(SF_LAST), sizeof(union Option_8E9F45));
};

void hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_OperatingRegion_out_id(STACK_FRAME_ONLY) {
  #ifdef SIREUM_LOC
  StackFrame sf = caller;
  #endif
  sfUpdateLoc(59);
  _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_OperatingRegion_out_id = art_Port_45E54D_id_(hamr_SW_CASE_AttestationGate_thr_Impl_Bridge_OperatingRegion_out_(hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_CASE_AttestationGateBridge(SF_LAST)));
};

void hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_OperatingRegion_out_port(STACK_FRAME_ONLY) {
  #ifdef SIREUM_LOC
  StackFrame sf = caller;
  #endif
  sfUpdateLoc(60);
  Type_assign(&_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_OperatingRegion_out_port, hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_noData(SF_LAST), sizeof(union Option_8E9F45));
};

void hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_LineSearchTask_in_id(STACK_FRAME_ONLY) {
  #ifdef SIREUM_LOC
  StackFrame sf = caller;
  #endif
  sfUpdateLoc(63);
  _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_LineSearchTask_in_id = art_Port_45E54D_id_(hamr_SW_CASE_AttestationGate_thr_Impl_Bridge_LineSearchTask_in_(hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_CASE_AttestationGateBridge(SF_LAST)));
};

void hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_LineSearchTask_in_port(STACK_FRAME_ONLY) {
  #ifdef SIREUM_LOC
  StackFrame sf = caller;
  #endif
  sfUpdateLoc(64);
  Type_assign(&_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_LineSearchTask_in_port, hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_noData(SF_LAST), sizeof(union Option_8E9F45));
};

void hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_LineSearchTask_out_id(STACK_FRAME_ONLY) {
  #ifdef SIREUM_LOC
  StackFrame sf = caller;
  #endif
  sfUpdateLoc(67);
  _hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_LineSearchTask_out_id = art_Port_45E54D_id_(hamr_SW_CASE_AttestationGate_thr_Impl_Bridge_LineSearchTask_out_(hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_CASE_AttestationGateBridge(SF_LAST)));
};

void hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_init_LineSearchTask_out_port(STACK_FRAME_ONLY) {
  #ifdef SIREUM_LOC
  StackFrame sf = caller;
  #endif
  sfUpdateLoc(68);
  Type_assign(&_hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_LineSearchTask_out_port, hamr_SW_Impl_Instance_AM_Gate_CASE_AttestationGate_CASE_AttestationGate_noData(SF_LAST), sizeof(union Option_8E9F45));
};