#include <all.h>
#include <ext.h>

// add c extension code here