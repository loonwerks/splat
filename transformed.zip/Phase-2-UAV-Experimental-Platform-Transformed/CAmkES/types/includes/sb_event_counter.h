#pragma once

#include <stdint.h>

typedef _Atomic uintmax_t sb_event_counter_t;
