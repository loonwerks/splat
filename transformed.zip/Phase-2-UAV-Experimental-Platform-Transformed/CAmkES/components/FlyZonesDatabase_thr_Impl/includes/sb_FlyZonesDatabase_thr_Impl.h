// This file will be regenerated, do not edit

#ifndef SB_FLYZONESDATABASE_THR_IMPL_H
#define SB_FLYZONESDATABASE_THR_IMPL_H

#include <sb_types.h>

bool sb_keep_in_zones_write(const union_art_DataContent * value);

bool sb_keep_out_zones_write(const union_art_DataContent * value);

#endif // SB_FLYZONESDATABASE_THR_IMPL_H
