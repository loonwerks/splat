// This file will be regenerated, do not edit

#ifndef SB_CASE_MONITOR_REQ_THR_IMPL_H
#define SB_CASE_MONITOR_REQ_THR_IMPL_H

#include <sb_types.h>

bool sb_observed_dequeue(union_art_DataContent *);

bool sb_reference_1_dequeue(union_art_DataContent *);

#endif // SB_CASE_MONITOR_REQ_THR_IMPL_H
