// This file will be regenerated, do not edit

#ifndef SB_CASE_FILTER_OR_THR_IMPL_H
#define SB_CASE_FILTER_OR_THR_IMPL_H

#include <sb_types.h>

bool sb_filter_in_dequeue(union_art_DataContent *);

bool sb_filter_out_enqueue(const union_art_DataContent *);

#endif // SB_CASE_FILTER_OR_THR_IMPL_H
