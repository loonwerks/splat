// This file will be regenerated, do not edit

#ifndef SB_UARTDRIVER_IMPL_H
#define SB_UARTDRIVER_IMPL_H

#include <sb_types.h>

bool sb_MissionCommand_dequeue(union_art_DataContent *);

bool sb_AirVehicleState_WPM_enqueue(const union_art_DataContent *);

bool sb_AirVehicleState_UXAS_enqueue(const union_art_DataContent *);

#endif // SB_UARTDRIVER_IMPL_H
